
package org.networkcount;

import scala.Tuple2;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.api.java.StorageLevels;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.Time;

import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaReceiverInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.networkcount.util.JavaConn;

import java.util.Arrays;
import java.util.regex.Pattern;
//spark-submit --class org.networkcount.JavaNetworkWordCount --master spark://192.168.100.94:8070 javaSpark/NetCount.jar 192.168.100.51 10000 1000
/*
 *��Ƶͳ��
 * Usage: JavaNetworkWordCount <hostname> <port> <interval>
 * ���� JavaNetworkWordCount ������ �˿�  ʱ�䳤�� (��λms)
 * */
public final class JavaNetworkWordCount {
  private static final Pattern SPACE = Pattern.compile(" ");

  /**
 * @param args
 */
public static void main(String[] args) {
    if (args.length < 3) {
      System.err.println("Usage: JavaNetworkWordCount <hostname> <port> <interval> [Socket_Connection_num]");
      System.exit(1);
    }
    SparkConf sparkConf = new SparkConf().setAppName("NetworkDataCount");
    

    
    
    JavaStreamingContext ssc = new JavaStreamingContext(sparkConf, Durations.milliseconds(Long.parseLong(args[2])));

    
    int numconn=1;
    if(args.length>3)
    	numconn=Integer.parseInt(args[3]);
    int port=Integer.parseInt(args[1]);
	JavaDStream<String> lines = JavaConn.buildDStreamBySample(ssc, args[0], port, numconn);
	
	
    JavaDStream<String> words = lines.flatMap(new FlatMapFunction<String, String>() {
      @Override
      public Iterable<String> call(String x) {
    	 return  Arrays.asList(SPACE.split(x));
      }
    });
    
    
    JavaPairDStream<String, Integer> wordCounts = words.mapToPair(
      new PairFunction<String, String, Integer>() {
        @Override
        public Tuple2<String, Integer> call(String s) {
          return new Tuple2<String, Integer>(s, 1);
        }
      }).reduceByKey(new Function2<Integer, Integer, Integer>() {
        @Override
        public Integer call(Integer i1, Integer i2) {
          return i1 + i2;
        }
      });
    wordCounts.print();
    ssc.start();
    ssc.awaitTermination();
  }
}
