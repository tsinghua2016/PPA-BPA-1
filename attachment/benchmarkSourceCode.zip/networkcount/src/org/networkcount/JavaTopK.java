package org.networkcount;
import scala.Tuple2;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.Function3;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.StorageLevels;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.Time;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaReceiverInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.networkcount.util.JavaConn;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
public class JavaTopK {
/*
 * ɸѡ����Ƶ��ߵ�topnum����
 * */
	private static final Pattern SPACE = Pattern.compile(" ");
	public static void main(final String[] args) {
	    if (args.length < 4) {
	      System.err.println("Usage: JavaTopK <hostname> <port> <interval> <topnum>  [Socket_Connection_num]");
	      System.exit(1);
	    }
	    final int topnum=Integer.parseInt(args[3]);
	    SparkConf sparkConf = new SparkConf().setAppName("JavaTopK");
	    JavaStreamingContext ssc = new JavaStreamingContext(sparkConf, Durations.milliseconds(Long.parseLong(args[2])));
	    int numconn=1;
	    if(args.length>4)
	    	numconn=Integer.parseInt(args[4]);
	    int port=Integer.parseInt(args[1]);
	    
		JavaDStream<String> lines = JavaConn.buildDStreamBySample(ssc, args[0], port, numconn);
	    
	    JavaDStream<String> words = lines.flatMap(new FlatMapFunction<String, String>() {
	      @Override
	      public Iterable<String> call(String x) {
	    	 return  Arrays.asList(SPACE.split(x));
	      }
	    });
	    JavaPairDStream<String, Integer> wordCounts = words.mapToPair(
	      new PairFunction<String, String, Integer>() {
	        @Override
	        public Tuple2<String, Integer> call(String s) {
	          return new Tuple2<String, Integer>(s, 1);
	        }
	      }).reduceByKey(new Function2<Integer, Integer, Integer>() {
	        @Override
	        public Integer call(Integer i1, Integer i2) {
	          return i1 + i2;
	        }
	      });
	    JavaDStream<Tuple2<String, Integer>> result = wordCounts.toJavaDStream().transform(new Function<JavaRDD<Tuple2<String,Integer>>, JavaRDD<Tuple2<String,Integer>>>() {
			@Override
			public JavaRDD<Tuple2<String,Integer>> call(
					JavaRDD<Tuple2<String,Integer>> arg0) throws Exception {
				// TODO Auto-generated method stub
				return arg0.sortBy(new Function<Tuple2<String,Integer>, Integer>() {

					@Override
					public Integer call(Tuple2<String,Integer> arg0)
							throws Exception {
						// TODO Auto-generated method stub
						return arg0._2;
					}
				}, false, 1);
				
			}
		});
	 /*   JavaDStream<Tuple2<Integer, String>> temp = wordCounts.map(new Function<Tuple2<String,Integer>, Tuple2<Integer,String>>() {

			@Override
			public Tuple2<Integer, String> call(Tuple2<String, Integer> arg0)
					throws Exception {
				// TODO Auto-generated method stub
				return new Tuple2<Integer, String>(arg0._2, arg0._1);
			}
		});
	
	    JavaDStream<Tuple2<Integer, String>> result = temp.transform(new Function<JavaRDD<Tuple2<Integer,String>>, JavaRDD<Tuple2<Integer,String>>>() {
			@Override
			public JavaRDD<Tuple2<Integer, String>> call(
					JavaRDD<Tuple2<Integer, String>> arg0) throws Exception {
				// TODO Auto-generated method stub
				return arg0.sortBy(new Function<Tuple2<Integer,String>, Integer>() {

					@Override
					public Integer call(Tuple2<Integer, String> arg0)
							throws Exception {
						// TODO Auto-generated method stub
						return arg0._1;
					}
				}, false, 1);
				
			}
		});*/

	  result.foreachRDD(new Function<JavaRDD<Tuple2<String,Integer>>, Void>() {
		@Override
		public Void call(JavaRDD<Tuple2<String,Integer>> arg0) throws Exception {
			// TODO Auto-generated method stub
			List<Tuple2<String,Integer>> lists=arg0.take(topnum);
			System.out.println(System.currentTimeMillis()+"\n");
			for(Tuple2<String,Integer> item: lists)
				System.out.println("<  "+item._1+" : "+item._2+" >");
			System.out.println("");
			return null;
		}
	});
	    ssc.start();
	    ssc.awaitTermination();
	    
	  }
	}
