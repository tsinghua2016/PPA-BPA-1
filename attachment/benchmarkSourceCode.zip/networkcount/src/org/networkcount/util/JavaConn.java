package org.networkcount.util;

import org.apache.spark.api.java.StorageLevels;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaReceiverInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

public class JavaConn {
 public static JavaDStream<String> buildDStreamBySample(JavaStreamingContext ssc,String host,int port,int numconn)
 {
	 if(numconn<0) numconn=1;
	 JavaDStream<String> result=null;
	for(int i=0;i<numconn;i++)
    {
    	JavaReceiverInputDStream<String> temp= ssc.socketTextStream(
                host,port, StorageLevels.MEMORY_AND_DISK_SER);
    	if(result==null)
    		result=temp;
    	else
    		result=result.union(temp);
    }
	return result;
    

 }
	
}
